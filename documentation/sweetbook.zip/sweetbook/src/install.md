# Install sweetheart

## Windows 10

## Ubuntu 20.04 LTS