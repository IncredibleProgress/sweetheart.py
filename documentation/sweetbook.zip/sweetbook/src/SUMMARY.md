
[Welcome](./welcome.md)
[Installation]()
[Getting started]()
[Build documentations]()
[Bibliography](./biblio.md)

# Fast learning

- [Python](./python.md)
- [Html/Css]()
- [Data processing](./process.md)
- [Good practices]()

# Go further

- [Data science]()
- [Machine learning]()
- [Typescript]()

# In deep

- [Bash](./bash.md)
- [Rust]()

# Developpement

- [History of versions](./versions.md)
- [Contribute]()
