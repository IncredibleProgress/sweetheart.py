# Welcome !
*Sweetheart makes programming a joy leading you to best coding practices*

## foreword

I'm happy that you look interested by the Sweetheart project. I spent many hours on my free time to provide the best of what coding can offer to you. I thanks my wife and my children also for their long patience and understanding. Now discover what you really can do with computers and furthermore... at the speed-light!

 *Nicolas Champion, the Sweetheart creator*
