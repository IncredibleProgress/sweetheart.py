# Brython
* python within webbrowser *

``` python
from browser import window


```
