# TailwindCss

``` bash
npm install -D tailwindcss
npx tailwindcss init

npx tailwindcss -i ./src/input.css -o ./dist/output.css --watch
```