# Discovering Sweetheart 
*make programming a joy leading you to best coding practices*

## foreword

I'm happy that you look interested by the Sweetheart project. I spent many hours on my free time to provide the best of what coding can offer. I thank a lot my wife and my children also very much for their understanding and long patience. Now discover what you really can do with computers and furthermore at the light speed!

 *Nicolas Champion, the Sweetheart creator*

 ## getting started

 + [Sweetheart for newbies](empty.html)
 + [Quickstart guide]()
 + [Installation and first steps]()
 + [Learn Python and Html]()
 + [Dive into programming]()
